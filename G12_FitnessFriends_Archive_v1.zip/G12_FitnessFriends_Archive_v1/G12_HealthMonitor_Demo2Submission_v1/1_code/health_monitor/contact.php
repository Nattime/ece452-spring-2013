<?php
//must always include
include 'core/init.php';
include 'includes/overall/header.php';
?>
  <h1>Contact Us</h1>
  <p>Please email us at : <a href="mailto:contactus@rutgers.edu?subject=Contact us">email@rutgers.edu</a></p>

<?php include 'includes/overall/footer.php'; ?>