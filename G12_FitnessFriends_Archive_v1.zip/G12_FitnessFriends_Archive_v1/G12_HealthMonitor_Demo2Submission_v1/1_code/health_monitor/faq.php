<?php
	//must always include
	include 'core/init.php';
	include 'includes/overall/header.php';
?>
    
    <h1>FAQ</h1>
    
    <h4>What are we?</h4>
    <p>We are a group of students on a mission to create a healthier life style.</p>
    
    <h4>What do we do?</h4>
    <p>We help those who want to compete against friends by exercising and reaching to the top of the leaderboard.</p>
    
    <h4>What is this for?</h4>
    <p>This is to help better your health.</p>
    
    <h4>Why are we doing this?</h4>
    <p>We are doing this to help create healthy people and to get an A on a project.</p>
    
<?php include 'includes/overall/footer.php'; ?>