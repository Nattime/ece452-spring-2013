<footer>
	<div id="links">
    	<a href="faq.php">FAQ</a> | <a href="about.php">About</a> | <a href="contact.php">Contact Us</a>
    </div>
</footer>