<?php
	//must always include
	include 'core/init.php';
	include 'includes/overall/header.php';
?>
    
    <img src="images/image.jpg" alt="image" id="home_pic" />
	
    <div id="main_login">
    	<a href="register.php"><img src="images/register.png" alt="register" /></a>
        <a href="login.php"><img src="images/login.png" alt="login" /></a>
    </div>
    <div class="clear"></div>
<?php include 'includes/overall/footer.php'; ?>