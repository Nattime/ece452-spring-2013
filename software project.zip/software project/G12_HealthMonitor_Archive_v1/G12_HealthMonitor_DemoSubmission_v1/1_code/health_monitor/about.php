<?php
	//must always include
	include 'core/init.php';
	include 'includes/overall/header.php';
?>
    
    <h1>About</h1>
	
    <p>We are a group of students who want to create a program for those who want to better their lifestyle. In order to help encourage the user, the users are competing against friends and other users to reach the top of the leaderboard.</p>

<?php include 'includes/overall/footer.php'; ?>