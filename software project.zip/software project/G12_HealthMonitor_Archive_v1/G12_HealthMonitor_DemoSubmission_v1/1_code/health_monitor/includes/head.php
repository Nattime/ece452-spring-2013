<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Health Monitor - Group 12</title>
<link rel="stylesheet" type="text/css" href="css/global.css" />
<link rel="shortcut icon" href="images/g12_logo.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="css/content.css" />
</head>