<div class="login">
    <form action="login.php" method="post">
        Username:
        <input type="text" name="username" placeholder="Username" />
        Password :
        <input type="password" name="password" placeholder="Password" />
        <input type="submit" value="Login" />
        Forgotten your <a href="recover.php?mode=username">username</a> or <a href="recover.php?mode=password">password</a>
    </form>
</div>