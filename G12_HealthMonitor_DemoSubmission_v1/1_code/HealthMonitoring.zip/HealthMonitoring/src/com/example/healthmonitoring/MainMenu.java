package com.example.healthmonitoring;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookRequestError;
import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.RequestAsyncTask;
import com.facebook.Response;
import com.facebook.LoggingBehavior;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.Settings;

public class MainMenu extends Activity {
	final String [] dailyAdvices = new String[30];
	public String username;
	public String userEmail;
	public String userAge;
	public String userScore;
	//public String password;
	public String response = "";
	//public String APP_ID = "160629600779341";
	//public Facebook fb = new Facebook(APP_ID);
	
	private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
	private static final String PENDING_PUBLISH_KEY = "pendingPublishReauthorization";
	private boolean pendingPublishReauthorization = false;
	
    private Session.StatusCallback statusCallback = new SessionStatusCallback();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);//sets the view to main menu layout        
        final TextView user_welcome = (TextView) findViewById(R.id.textView1);//declares the welcome text
        final TextView dailyAdvice = (TextView) findViewById(R.id.dailyAdvice);//declares the daily advice text
        final String filename = "user accounts";
		final  SharedPreferences login_data = getSharedPreferences(filename, 0);//gets the login data from sharedprefs
        String activeUser = login_data.getString("activeUser", null);//declares the active user's first name into a string
        username = login_data.getString("activeUsername", null);//declares the active username into a string
        user_welcome.setText("Hello " + activeUser+ "!");//sets welcome text
        initializeAdvice();
        new GetLeaderboard().execute();
        new ConnectToServer().execute();
        Calendar c = Calendar.getInstance(); 
        dailyAdvice.setText(dailyAdvices[c.get(Calendar.DATE)]);
        
        //from here
        Settings.addLoggingBehavior(LoggingBehavior.INCLUDE_ACCESS_TOKENS);

        Session session = Session.getActiveSession();
        if (session == null) {
            if (savedInstanceState != null) {
                session = Session.restoreSession(this, null, statusCallback, savedInstanceState);
            }
            if (session == null) {
                session = new Session(this);
            }
            Session.setActiveSession(session);
            if (session.getState().equals(SessionState.CREATED_TOKEN_LOADED)) {
                session.openForRead(new Session.OpenRequest(this).setCallback(statusCallback));
            }
        }

        updateView();//up until here, are used for for facebook login purposes
    }
    
    @Override
	protected void onResume() {//this is used to declare a string
		// TODO Auto-generated method stub
		super.onResume();
        final TextView dailyAdvice = (TextView) findViewById(R.id.dailyAdvice);//declares the daily advice text
        Calendar c = Calendar.getInstance(); 
		dailyAdvice.setText(dailyAdvices[c.get(Calendar.DATE)-1]);
	}

	@Override
    public void onBackPressed(){
		moveTaskToBack(true);//moves app to background when back button is pressed
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    
    @Override
    public void onStart() {
        super.onStart();
        Session.getActiveSession().addCallback(statusCallback);
    }

    @Override
    public void onStop() {
        super.onStop();
        Session.getActiveSession().removeCallback(statusCallback);
    }
    
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
    }
    
    //saving facebook session
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Session session = Session.getActiveSession();
        Session.saveSession(session, outState);
    }
    
    public void initializeAdvice(){    	
    	InputStream inputStream = null;
		try {
			inputStream = getAssets().open("daily advices.txt");
		} catch (IOException e) {
			Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
		}
    	BufferedReader input = new BufferedReader(new InputStreamReader(inputStream));

    	for (int i=0;i<30;i++){
    		try {
				dailyAdvices[i] = input.readLine();
			} catch (Exception e) {
				Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
			}
        }
    }

	private void logIn(){
		Session session = Session.getActiveSession();
        if (!session.isOpened() && !session.isClosed()) {
            session.openForRead(new Session.OpenRequest(this).setCallback(statusCallback));
        } else {
            Session.openActiveSession(this, true, statusCallback);
        }
	}
	
    private void publishStory() {
        Session session = Session.getActiveSession();

        if (session != null){

            // Check for publish permissions    
            List<String> permissions = session.getPermissions();
            if (!isSubsetOf(PERMISSIONS, permissions)) {
                pendingPublishReauthorization = true;
                Session.NewPermissionsRequest newPermissionsRequest = new Session
                        .NewPermissionsRequest(this, PERMISSIONS);
            session.requestNewPublishPermissions(newPermissionsRequest);
                return;
            }

            Bundle postParams = new Bundle();
            postParams.putString("name", "Fitness Friends");
            postParams.putString("message", "Challenge me on Fitness Friends! My current score is "+userScore);
            postParams.putString("caption", "Challenge your friends in a workout competition!");
            postParams.putString("description", "Fitness Friends makes it easier and more fun to lose weight. Compare your scores with friends and or challenge them to a workout competition!");
            postParams.putString("link", "http://se1.engr.rutgers.edu/~13group12/home.php");
            postParams.putString("picture", "http://thumbs.dreamstime.com/thumblarge_450/12574588627J6i8E.jpg");

            Request.Callback callback= new Request.Callback() {
                public void onCompleted(Response response) {
                    JSONObject graphResponse = response
                                               .getGraphObject()
                                               .getInnerJSONObject();
                    String postId = null;
                    try {
                        postId = graphResponse.getString("id");
                    } catch (JSONException e) {
                        Toast.makeText(MainMenu.this, e.toString(), Toast.LENGTH_LONG);
                    }
                    FacebookRequestError error = response.getError();
                    if (error != null) {
                        Toast.makeText(MainMenu.this
                             .getApplicationContext(),
                             error.getErrorMessage(),
                             Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainMenu.this
                                 .getApplicationContext(), 
                                 "Your post is successful!",
                                 Toast.LENGTH_LONG).show();
                    }
                }
            };

            Request request = new Request(session, "me/feed", postParams, 
                                  HttpMethod.POST, callback);

            RequestAsyncTask task = new RequestAsyncTask(request);
            task.execute();
        }

    }
    
    private boolean isSubsetOf(Collection<String> subset, Collection<String> superset) {
        for (String string : subset) {
            if (!superset.contains(string)) {
                return false;
            }
        }
        return true;
    }
    
    public void makeAccountDialog(){
    	if(!userEmail.isEmpty()){//if useremail not empty then account info is succesfully fetched
    		
    		final AlertDialog.Builder accountDialog = new AlertDialog.Builder(MainMenu.this);
    		accountDialog.setMessage("Email: "+userEmail+"\n" +"Age: "+userAge+"\n"+"Your Score: "+userScore);
    		/*accountDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
    			public void onClick(DialogInterface dialog, int id) {
    				// do nothing, dismisses the dialog
    			}
    		});
    		accountDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
    			public void onClick(DialogInterface dialog, int id) {
    				// do nothing, dismisses the dialog
    			}
    		});*/
    		accountDialog.setNeutralButton("OK", new DialogInterface.OnClickListener() {
    			public void onClick(DialogInterface dialog, int id) {
    				// do nothing, dismisses the dialog
    			}
    		});
    		accountDialog.show();
    	}
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        	case R.id.account_info:
        		makeAccountDialog();
        		return true;
        	case R.id.share_score:
        		new ConnectToServer().execute();
        		Session session = Session.getActiveSession();
        		if(session.isClosed() && !session.isOpened()){
        			logIn();
        		}
        		else{
        			publishStory();
        		}
        		return true;
        	case R.id.search_username:
        		CompareScore compareScore = new CompareScore();
			    compareScore.show(getFragmentManager(), "find username");
			    return true;
        	case R.id.refresh_leaderboard:        		
        		new GetLeaderboard().execute();
        		new ConnectToServer().execute();
        		return true;
            case R.id.action_settings:
                // settings in action bar clicked; go to settings screen
                Intent intent1 = new Intent(this, SettingsActivity.class);
                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent1);
                return true;
            case R.id.log_out:
            	// log out in action bar clicked; g to login screen
            	Intent intent2 = new Intent(this, LoginScreenActivity.class);
            	final String filename = "user accounts";
        		SharedPreferences login_data = getSharedPreferences(filename, 0);//gets the login data from shared prefs
            	SharedPreferences.Editor editor = login_data.edit();
				editor.putBoolean("isLoggedIn", false);//iLoggedIn is set to false so that when user opens the app, it goes to login screen
				editor.commit();
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public class ConnectToServer extends AsyncTask<String, String, String> {
    	HttpPost httppost = new HttpPost("http://172.16.27.143/~13group12/androidconnect.php");
	    HttpClient httpclient = new DefaultHttpClient();
	    InputStream is = null;
		@Override
		protected String doInBackground(String... args) {
		       try{
		    	   	List params = new ArrayList();
		            //InputStream is = null;
		            params.add(new BasicNameValuePair("username", username));
		            params.add(new BasicNameValuePair("key", "13group12"));
		            httppost.setEntity(new UrlEncodedFormEntity(params));
		            HttpResponse httpResponse = httpclient.execute(httppost);
		            HttpEntity httpEntity = httpResponse.getEntity();
		            is = httpEntity.getContent();
		            String line = "";               
		            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
		            {
		                sb.append(line + "\n");
		            }
		            is.close();
		            // Response from server after login process will be stored in response variable.                
		            response = sb.toString(); 
		            reader.close();
		            if(!response.isEmpty()){
						 int pointer = 0;
						 userEmail = response.substring(pointer, response.indexOf(" "));
						 pointer = response.indexOf(" ");
						 userAge = response.substring(pointer, response.indexOf(" ", pointer+1));
						 pointer = response.indexOf(" ",pointer+1);
						 userScore = response.substring(pointer, response.length());
						 response = "";//reset response
					 }
		        }
		       catch (Exception e){
		    	   response = e.toString();
		       }
		       return null;
		}
		 protected void onPostExecute(String file_url) {
			 
		 }

		

	}
    
    public class GetLeaderboard extends AsyncTask<String, String, String> {
	    InputStream is = null;
		@Override
		protected String doInBackground(String... args) {
			HttpPost httppost = new HttpPost("http://172.16.27.143/~13group12/androidleaderboard.php");
			response = "";
		       HttpClient httpclient = new DefaultHttpClient();
		       try{
		    	   	List params = new ArrayList();
		            InputStream is = null;
		            params.add(new BasicNameValuePair("username", username));
		            params.add(new BasicNameValuePair("key", "13group12"));
		            httppost.setEntity(new UrlEncodedFormEntity(params));
		            HttpResponse httpResponse = httpclient.execute(httppost);
		            HttpEntity httpEntity = httpResponse.getEntity();
		            is = httpEntity.getContent();
		            
		            String line = "";               
		            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
		            {
		                sb.append(line + "\n");
		            }
		            is.close();
		            // Response from server after login process will be stored in response variable.                
		            response = sb.toString();            
		            reader.close();
		            
		       }
		       catch (Exception e){
		    	   response = e.toString();
		       }
		       return null;
		}
		 protected void onPostExecute(String file_url) {
		final TextView user1 = (TextView) findViewById(R.id.user1);
    	final TextView user2 = (TextView) findViewById(R.id.user2);
    	final TextView user3 = (TextView) findViewById(R.id.user3);
    	final TextView user4 = (TextView) findViewById(R.id.user4);
    	final TextView user5 = (TextView) findViewById(R.id.user5);
    	final TextView user1Age = (TextView) findViewById(R.id.user1_age);
    	final TextView user2Age = (TextView) findViewById(R.id.user2_age);
    	final TextView user3Age = (TextView) findViewById(R.id.user3_age);
    	final TextView user4Age = (TextView) findViewById(R.id.user4_age);
    	final TextView user5Age = (TextView) findViewById(R.id.user5_age);
    	final TextView user1Score = (TextView) findViewById(R.id.user1_score);
    	final TextView user2Score = (TextView) findViewById(R.id.user2_score);
    	final TextView user3Score = (TextView) findViewById(R.id.user3_score);
    	final TextView user4Score = (TextView) findViewById(R.id.user4_score);
    	final TextView user5Score = (TextView) findViewById(R.id.user5_score);
    	if(!response.isEmpty()){
    		int pointer = 0;
    		String [] usernames = new String[5];
    		String [] scores = new String[5];
    		String [] ages = new String[5];
    		for(int i=0;i<5;i++){
    			usernames[i] = response.substring(response.indexOf(" ", pointer),response.indexOf(" ", pointer+1));
    			pointer=response.indexOf(" ", pointer+1);
    			ages[i] = response.substring(response.indexOf(" ", pointer),response.indexOf(" ", pointer+1));
    			pointer=response.indexOf(" ", pointer+1);
    			scores[i] = response.substring(response.indexOf(" ", pointer),response.indexOf(" ", pointer+1));
    			pointer=response.indexOf(" ", pointer+1);
    		}
    		user1.setText(usernames[0]);
    		user2.setText(usernames[1]);
    		user3.setText(usernames[2]);
    		user4.setText(usernames[3]);
    		user5.setText(usernames[4]);
    		user1Score.setText(scores[0]);
    		user2Score.setText(scores[1]);
    		user3Score.setText(scores[2]);
    		user4Score.setText(scores[3]);
    		user5Score.setText(scores[4]);
    		user1Age.setText(ages[0]);
    		user2Age.setText(ages[1]);
    		user3Age.setText(ages[2]);
    		user4Age.setText(ages[3]);
    		user5Age.setText(ages[4]);
    		response = ""; //reset response
    	}
		 }

	}
    //for facebook sharing purposes
    private void updateView() {
        Session session = Session.getActiveSession();
        /*if (session.isOpened()) {
            textInstructionsOrLink.setText(URL_PREFIX_FRIENDS + session.getAccessToken());
            buttonLoginLogout.setText(R.string.logout);
            buttonLoginLogout.setOnClickListener(new OnClickListener() {
                public void onClick(View view) { onClickLogout(); }
            });
        } else {
            textInstructionsOrLink.setText(R.string.instructions);
            buttonLoginLogout.setText(R.string.login);
            buttonLoginLogout.setOnClickListener(new OnClickListener() {
                public void onClick(View view) { onClickLogin(); }
            });
        }*/
    }
    
    private class SessionStatusCallback implements Session.StatusCallback {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            updateView();
        }
    }
}
