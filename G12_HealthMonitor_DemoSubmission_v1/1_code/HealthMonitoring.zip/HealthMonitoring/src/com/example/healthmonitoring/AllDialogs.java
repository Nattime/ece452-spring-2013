package com.example.healthmonitoring;
import java.util.Set;
import java.util.TreeSet;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.ActionBar;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

public class AllDialogs extends DialogFragment{
	final int REGISTER_DIALOG = 0;
	final int INVALID_USRPW = 1;
	
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View view = inflater.inflate(R.layout.register_dialog, null);
        final TextView registerText = (TextView) view.findViewById(R.id.textView1);
        final Button login_Button = (Button) view.findViewById(R.id.login_button);
        Context context = view.getContext();
        /*context.registerText.setOnClickListener(new view.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showDialog(0);
			}
		});*/
        return builder.create();
	}
}
