package com.example.healthmonitoring;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Context;
import android.content.DialogInterface;

public class RegisterDialog extends DialogFragment{
	String response = "";
	String username = "";
	String password= "";
	String retypePassword= "";
	String firstName= "";
	String lastName= "";
	String emailAddress= "";
	String age= "";
	String weight= "";
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();//inflater for dialog layout
        final View view = inflater.inflate(R.layout.register_dialog, null);//inflate the register dialog
        builder.setView(view);
        final EditText register_username_box = (EditText) view.findViewById(R.id.register_username);//declares the username field
        final EditText register_password_box = (EditText) view.findViewById(R.id.register_password);//declares the password field
        final EditText first_name_box = (EditText) view.findViewById(R.id.first_name);// declares the first name field
        final EditText last_name_box = (EditText) view.findViewById(R.id.last_name);//declares the last name field
        final EditText retype_password_box = (EditText) view.findViewById(R.id.retype_password);//declares the last name field
        final EditText email_address = (EditText) view.findViewById(R.id.email_address);//declares the last name field
        final EditText age_box = (EditText) view.findViewById(R.id.age_box);//declares the last name field
        final EditText weight_box = (EditText) view.findViewById(R.id.weight_box);//declares the last name field
        
        Context context = view.getContext();
		//final SharedPreferences login_data = context.getSharedPreferences("user accounts", 0);
        builder.setPositiveButton(R.string.register, new DialogInterface.OnClickListener() {//sets the actions taken when register button is pressed
                   public void onClick(DialogInterface dialog, int id) {
                       //if the fields are not empty:
       		            	username = register_username_box.getText().toString();
       		            	password = register_password_box.getText().toString();
       		            	retypePassword = retype_password_box.getText().toString();
       		            	firstName = first_name_box.getText().toString();
       		            	lastName = last_name_box.getText().toString();
    		            	emailAddress = email_address.getText().toString();
    		            	age = age_box.getText().toString();
    		            	weight = weight_box.getText().toString();
                		   	new RegisterAccount().execute();
                		   	Calendar c = Calendar.getInstance();
                		   	int second = c.get(Calendar.SECOND)+30;
                		   	while (second != c.get(Calendar.SECOND)){//if no connection, try 30 seconds
                		   		new RegisterAccount().execute();
                		   		if(response == ""){
                		   			break;
                		   		}
                		   	}
                		   	

                		   	
                		   	if(response !=""){
                		   		if(response.contains("Registered successfully")){
                		   			response = response.substring(response.indexOf("Registered"), response.indexOf("Registered")+70);
                		   		}
                		   		else{
                		   			response = response.substring(response.indexOf("<ul><li>")+8, response.indexOf("</li></ul>"));
                		   		}
                		   		Toast.makeText(getActivity(), response, 1).show();
                		   	}
                		   	else{
                		   		Toast.makeText(getActivity(), "No connection.", 1).show();
                		   	}
                   }
               })                                                                                     
               .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       // User cancelled the dialog, do nothing
                   }
               });
        // Create the AlertDialog object and return it
        return builder.create();
    }
	public class RegisterAccount extends AsyncTask<String, String, String> {
		ProgressDialog pDialog;
		
		@Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Registering your account...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
		@Override
		protected String doInBackground(String... args) {
			HttpPost httppost = new HttpPost("http://172.16.27.143/~13group12/register.php");
		       HttpClient httpclient = new DefaultHttpClient();
		       try{
		    	   	List params = new ArrayList();
		            InputStream is = null;
		            params.add(new BasicNameValuePair("username", username));
		            params.add(new BasicNameValuePair("password", password));
		            params.add(new BasicNameValuePair("password2", retypePassword));
		            params.add(new BasicNameValuePair("first_name", firstName));
		            params.add(new BasicNameValuePair("last_name", lastName));
		            params.add(new BasicNameValuePair("email", emailAddress));
		            params.add(new BasicNameValuePair("age", age));
		            params.add(new BasicNameValuePair("weight", weight));
		            httppost.setEntity(new UrlEncodedFormEntity(params));
		            HttpResponse httpResponse = httpclient.execute(httppost);
		            HttpEntity httpEntity = httpResponse.getEntity();
		            is = httpEntity.getContent();
		            String line = "";               
		            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
		            {
		                sb.append(line + "\n");
		            }
		            is.close();
		            // Response from server after login process will be stored in response variable.                
		            response = sb.toString();            
		            reader.close();
		        }
		       catch (Exception e){
		    	   response = e.toString();
		       }
		       return null;
		}
		 protected void onPostExecute(String file_url) {
	            // dismiss the dialog after connection is ended
	            pDialog.dismiss();
	            
		}
	}
}
