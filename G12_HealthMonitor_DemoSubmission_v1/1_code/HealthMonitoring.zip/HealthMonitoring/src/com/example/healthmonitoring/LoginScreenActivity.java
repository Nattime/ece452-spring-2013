package com.example.healthmonitoring;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import com.example.healthmonitoring.RegisterDialog.RegisterAccount;

import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ActionBar;
import android.content.Intent;
import android.content.SharedPreferences;


public class LoginScreenActivity extends Activity {
	SharedPreferences login_data;
	boolean isLoggedIn;
	boolean usernameExists;
	String username;
	String password;
	String response = "No connection."; 
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		final Intent intent = new Intent(this, MainMenu.class);
		final String filename = "user accounts";
		login_data = getSharedPreferences(filename, 0);//gets login data from shared prefs
		isLoggedIn = login_data.getBoolean("isLoggedIn", false);
		if(isLoggedIn){
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);//if user is logged in, go straight to main menu activity
		}
		super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);//if not, app goes to login screen
        ActionBar actionBar = getActionBar();
        actionBar.hide();//action bar is hidden in login screen
        final Button login_Button = (Button) findViewById(R.id.login_button);//declares login button
        final EditText username_box = (EditText) findViewById(R.id.age_box);//declares username field
        final EditText password_box = (EditText) findViewById(R.id.retype_password);//declares password field
        final TextView register = (TextView) findViewById(R.id.textView1);//declares register button which is a text
        login_Button.setOnClickListener(new View.OnClickListener(){//defines the action taken when login button is presed 
        	//url ip 172.16.27.143
			@Override
			public void onClick(View v) {
				if(username_box.getText().toString().length()!= 0 && password_box.getText().toString().length()!= 0){
					username = username_box.getText().toString();//gets username from username box and converts it to string
					password = password_box.getText().toString();//gets password from password box and converts it to string
					Calendar c = Calendar.getInstance();
        		   	int second = c.get(Calendar.SECOND)+30;
        		   	while (second != c.get(Calendar.SECOND)){//if no connection, try 30 seconds
        		   		new LoginConnection().execute();
        		   		if(response != ""){
        		   			break;
        		   		}
        		   	}
					if(response==null){
						toastGenerator("No connection");
					}
				}
				else {
		            toastGenerator("Please enter username/password.");
				}
				if(usernameExists){//if account exists,
					isLoggedIn = true;
					String activeUser = response.substring(response.indexOf("Welcome,")+11, response.indexOf("</h2><div")-3);
					//String activeUser = response.substring(560,570);
					SharedPreferences.Editor editor = login_data.edit();
					editor.putBoolean("isLoggedIn", isLoggedIn);
					editor.putString("activeUser", activeUser);
					editor.putString("activeUsername", username);
					editor.commit();
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	                startActivity(intent);//app goes to main menu.
				}
				else{
					DialogFragment newFragment = new LoginDialog();
				    newFragment.show(getFragmentManager(), "login failed");//else, a dialog will appear and tells that login is failed.
				}
			}
        });

        register.setOnClickListener(new View.OnClickListener() {//sets action taken if register button is pressed
        	
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				DialogFragment registerDialog = new RegisterDialog();
			    registerDialog.show(getFragmentManager(), "register");//a register dialog will appear on top of login screen
			}
		});
	}
	
	public void toastGenerator(String text){
		Toast.makeText(this, text, 0).show();
		
	}
	
	public class LoginConnection extends AsyncTask<String, String, String> {
		ProgressDialog pDialog;
		
		@Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(LoginScreenActivity.this);
            pDialog.setMessage("Logging you in...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
		@Override
		protected String doInBackground(String... args) {
		       HttpPost httppost = new HttpPost("http://172.16.27.143/~13group12/login.php");
		       HttpClient httpclient = new DefaultHttpClient();
		       try{
		    	   	List params = new ArrayList();
		            URL url = null;   
		            InputStream is = null;
		            params.add(new BasicNameValuePair("username", username));
		            params.add(new BasicNameValuePair("password", password));
		            httppost.setEntity(new UrlEncodedFormEntity(params));
		            HttpResponse httpResponse = httpclient.execute(httppost);
		            HttpEntity httpEntity = httpResponse.getEntity();
		            is = httpEntity.getContent();
		            
		            String line = "";               
		            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
		            {
		                sb.append(line + "\n");
		            }
		            is.close();
		            // Response from server after login process will be stored in response variable.                
		            response = sb.toString();            
		            reader.close();
		            if(response.contains("Welcome")){
		            	usernameExists = true;
		            }
		        }
		       catch (Exception e){
		    	   response = e.toString();
		       }
		       return null;
		}
		 protected void onPostExecute(String file_url) {
	            // dismiss the dialog after connection is ended
	            pDialog.dismiss();
	            
		}
	}
}
