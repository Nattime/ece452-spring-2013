package com.example.healthmonitoring;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class CompareScore extends DialogFragment{
	String username = "";
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		LayoutInflater inflater = getActivity().getLayoutInflater();//inflater for dialog layout
		final View view = inflater.inflate(R.layout.input_username, null);//inflate the register dialog
    	builder.setView(view);
    	final EditText find_username_box = (EditText) view.findViewById(R.id.find_username);//declares the username field
    	Context context = view.getContext();
    	builder.setPositiveButton(R.string.compare, new DialogInterface.OnClickListener() {//sets the actions taken when register button is pressed
            public void onClick(DialogInterface dialog, int id) {
            	username = find_username_box.getText().toString();
            	
            }
    	})
    	
            .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    // User cancelled the dialog, do nothing
                }
            });
    	return builder.create();
	}
}
