package com.example.healthmonitoring;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.Calendar;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;

public class GraphActivity extends Activity{
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        setContentView(R.layout.graph_layout);
        /*final Button graph_Button = (Button) findViewById(R.id.imageButton1);
        final Intent intent = new Intent(this, GraphActivity.class);
        graph_Button.setOnClickListener(new View.OnClickListener(){
        	
			@Override
			public void onClick(View v) {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
			}
        });*/
	}
}
